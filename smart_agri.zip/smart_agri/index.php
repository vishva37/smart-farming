<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<?php include('includes/header.php'); ?>
<h2 style="text-align:center;">Welcome to Smart Agri 2.0</h2>
<p style="text-align:center;">Your smart agriculture assistant — get crop info, fertilizer tips, and weather updates!</p>
<?php include('includes/footer.php'); ?>
