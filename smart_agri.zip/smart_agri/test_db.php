<?php
include('config.php');
echo "✅ Database connection is working!";
?>
