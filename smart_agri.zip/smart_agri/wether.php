<?php include('includes/header.php'); ?>
<h2 style="text-align:center;">Live Weather</h2>
<div style="text-align:center;">
  <input type="text" id="city" placeholder="Enter city name" style="padding:8px;width:40%;border-radius:8px;">
  <button onclick="getWeather()">Check</button>
  <p id="result" style="margin-top:20px;"></p>
</div>
<script src="js/weather.js"></script>
<?php include('includes/footer.php'); ?>
