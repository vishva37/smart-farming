CREATE DATABASE IF NOT EXISTS smart_agri2;
USE smart_agri2;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE crops (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  season VARCHAR(50),
  soil_type VARCHAR(100),
  description TEXT
);

CREATE TABLE fertilizers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  crop_id INT,
  name VARCHAR(100),
  purpose TEXT,
  dosage VARCHAR(100),
  FOREIGN KEY (crop_id) REFERENCES crops(id)
);

INSERT INTO crops (name, season, soil_type, description) VALUES
('Rice', 'Kharif', 'Clayey', 'Rice needs standing water and rich clay soil.'),
('Wheat', 'Rabi', 'Loamy', 'Wheat prefers cool weather and loamy soil.'),
('Maize', 'Kharif', 'Sandy loam', 'Maize grows well in well-drained soils.');

INSERT INTO fertilizers (crop_id, name, purpose, dosage) VALUES
(1, 'Urea', 'Increases nitrogen for growth', '50kg/acre'),
(2, 'MOP', 'Provides potassium for yield', '25kg/acre'),
(3, 'NPK 20:20:0', 'Balanced nutrients', '40kg/acre');
