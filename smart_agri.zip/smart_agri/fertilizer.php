<?php
// Show all errors for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');
include('includes/header.php');

$crop = isset($_GET['crop']) ? trim($_GET['crop']) : '';

// Detect actual column names in the database to avoid unknown-column errors
$fertCol = null;
$cropCol = null;

$resCols = $conn->query("SHOW COLUMNS FROM fertilizers");
if ($resCols) {
    $fields = [];
    while ($c = $resCols->fetch_assoc()) {
        $fields[] = $c['Field'];
    }
    // Prefer common column names
    if (in_array('name', $fields)) $fertCol = 'name';
    elseif (in_array('fertilizer_name', $fields)) $fertCol = 'fertilizer_name';
    elseif (in_array('fertilizer', $fields)) $fertCol = 'fertilizer';
    else $fertCol = $fields[0] ?? null;
}

$resCropCols = $conn->query("SHOW COLUMNS FROM crops");
if ($resCropCols) {
    $cfields = [];
    while ($c = $resCropCols->fetch_assoc()) {
        $cfields[] = $c['Field'];
    }
    if (in_array('name', $cfields)) $cropCol = 'name';
    elseif (in_array('crop_name', $cfields)) $cropCol = 'crop_name';
    else $cropCol = $cfields[0] ?? null;
}

// Build a safe SELECT using detected columns; if detection failed, fall back to sensible defaults
if (!$fertCol) $fertCol = 'name';
if (!$cropCol) $cropCol = 'name';

$sql = "SELECT crops." . $conn->real_escape_string($cropCol) . " AS crop_name, fertilizers." . $conn->real_escape_string($fertCol) . " AS fertilizer_name, fertilizers.purpose, fertilizers.dosage ";
$sql .= "FROM fertilizers LEFT JOIN crops ON fertilizers.crop_id = crops.id";

if ($crop !== '') {
  $safe = $conn->real_escape_string($crop);
  $sql .= " WHERE crops." . $conn->real_escape_string($cropCol) . " LIKE '%$safe%'";
}

$result = $conn->query($sql);
?>

<h2 class="center">Fertilizer Finder</h2>

<div style="text-align:center;margin-bottom:20px;">
  <form method="GET">
    <input type="text" name="crop" placeholder="Enter crop name..." value="<?= htmlspecialchars($crop) ?>" style="padding:8px;width:40%;border-radius:8px;">
    <button type="submit" style="padding:8px 15px;">Search</button>
  </form>
</div>

<table>
  <thead>
    <tr>
      <th>Crop</th>
      <th>Fertilizer</th>
      <th>Purpose</th>
      <th>Dosage</th>
    </tr>
  </thead>
  <tbody>
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['crop_name'] ?? 'Unknown') ?></td>
          <td><?= htmlspecialchars($row['fertilizer_name'] ?? '—') ?></td>
          <td><?= htmlspecialchars($row['purpose'] ?? '') ?></td>
          <td><?= htmlspecialchars($row['dosage'] ?? '') ?></td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="4" style="text-align:center;">No fertilizers found</td></tr>
    <?php endif; ?>
  </tbody>
</table>

<?php include('includes/footer.php'); ?>
