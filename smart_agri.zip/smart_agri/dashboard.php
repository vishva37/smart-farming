<?php include('includes/header.php'); ?>
<h2 style="text-align:center;">Welcome to Your Dashboard, <?php echo $_SESSION['username'] ?? 'Guest'; ?>!</h2>
<p style="text-align:center;">Use the menu to navigate and explore crop, fertilizer, and weather data.</p>
<?php include('includes/footer.php'); ?>
