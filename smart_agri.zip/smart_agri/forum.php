<?php include('config.php'); include('includes/header.php'); ?>
<h2 style="text-align:center;">Farmer Forum</h2>
<div style="text-align:center;">
<form method="POST">
  <textarea name="question" placeholder="Ask your question..." required style="width:50%;height:60px;"></textarea><br>
  <button type="submit" name="post">Post Question</button>
</form>
</div>
<?php
if(isset($_POST['post'])){
 $q=$conn->real_escape_string($_POST['question']);
 $conn->query("INSERT INTO forum_questions(question) VALUES('$q')");
 echo "<script>location.href='forum.php';</script>";
}
$res=$conn->query("SELECT * FROM forum_questions ORDER BY created_at DESC");
while($r=$res->fetch_assoc()){
 echo "<div style='width:60%;margin:auto;background:#fff;padding:10px;margin-top:10px;border-radius:10px;'>
 <strong>Q:</strong> {$r['question']}<br><small>{$r['created_at']}</small></div>";
}
include('includes/footer.php');
?>
