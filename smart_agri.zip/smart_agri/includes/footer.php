</main>
<footer class="footer">
  <p>© 2025 Smart Agri 2.0 | Built with HTML, CSS, JS, PHP & MySQL</p>
</footer>
</body>
</html>
