<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Smart Agri 2.0</title>
  <link rel="stylesheet" href="css/styles.css">
  <style>
    .banner-image {
      width: 100%;
      height: 250px;
      object-fit: cover;
      margin-bottom: 0;
      display: block;
      background-color: #e0f2e9;
    }
    .navbar {
      position: relative;
      z-index: 1000;
    }
  </style>
</head>
<body>
<header>
  <img src=".C:\xampp\htdocs\smart_agri\images.jpeg" alt="Smart Agriculture Banner" class="banner-image" onerror="this.style.display='none'">
  <nav class="navbar">
    <div class="logo"><img src="/smart_agri/images.jpeg" style="height: 60px; width: 60px; vertical-align: middle; margin-right: 5px;"> Smart Agri 2.0</div>
    <ul class="nav-links">
      <li><a href="index.php">Home</a></li>
      <li><a href="crops.php">Crops</a></li>
      <li><a href="fertilizer.php">Fertilizers</a></li>
      <li><a href="weather.php">Weather</a></li>
      <li><a href="forum.php">Forum</a></li>
      <?php if(isset($_SESSION['username'])): ?>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="logout.php">Logout</a></li>
      <?php else: ?>
        <li><a href="login.php">Login</a></li>
        <li><a href="register.php">Register</a></li>
      <?php endif; ?>
    </ul>
  </nav>
</header>
<main>
