<?php include('config.php'); include('includes/header.php'); ?>
<h2 style="text-align:center;">Login</h2>
<div style="text-align:center;">
<form method="POST">
  <input type="text" name="username" placeholder="Username" required><br><br>
  <input type="password" name="password" placeholder="Password" required><br><br>
  <button type="submit" name="login">Login</button>
</form>
</div>
<?php
if(isset($_POST['login'])){
  $u = trim($_POST['username']);
  $p = $_POST['password'];

  // Our users table uses the `name` column for username
  $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
  if ($stmt) {
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
      $row = $res->fetch_assoc();
      // Verify hashed password
      if (password_verify($p, $row['password'])) {
        $_SESSION['username'] = $u;
        header("Location: dashboard.php");
        exit;
      }
    }
    echo "<p style='color:red;text-align:center;'>Invalid credentials!</p>";
    $stmt->close();
  } else {
    echo "<p style='color:red;text-align:center;'>Login error: " . htmlspecialchars($conn->error) . "</p>";
  }
}
include('includes/footer.php');
?>
