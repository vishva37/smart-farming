<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "smart_agri";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// OpenWeatherMap API key (optional). Add your API key here for the weather widget.
$openweather_api_key = "37eefb066f3ccf699d8343b78d04161b"; // OpenWeatherMap API key
?>
