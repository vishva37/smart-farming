<?php include 'includes/header.php'; include 'config.php'; ?>
<h2 style="text-align:center;margin-top:30px;">Crop Information</h2>
<input type="text" id="cropSearch" placeholder="Search crop..." style="display:block;margin:15px auto;width:60%;padding:10px;border-radius:8px;">
<table id="cropTable">
  <tr><th>Crop</th><th>Season</th><th>Soil Type</th><th>Description</th></tr>
  <?php
    $res=$conn->query("SELECT * FROM crops");
    while($r=$res->fetch_assoc()){
      echo "<tr><td>{$r['name']}</td><td>{$r['season']}</td><td>{$r['soil_type']}</td><td>{$r['description']}</td></tr>";
    }
  ?>
</table>
<script>
const s=document.getElementById("cropSearch");
s.addEventListener("keyup",()=>{
  const f=s.value.toLowerCase();
  document.querySelectorAll("#cropTable tr").forEach((r,i)=>{
    if(i===0)return;
    r.style.display=r.innerText.toLowerCase().includes(f)?'':'none';
  });
});
</script>
<?php include 'includes/footer.php'; ?>
