<?php include 'config.php'; include 'includes/header.php'; ?>

<h2 style="text-align:center;margin-top:20px;">Check the Weather</h2>
<div style="text-align:center;margin:18px 0;">
  <input id="city" type="text" placeholder="Enter city name..." style="padding:8px;width:40%;border-radius:8px;">
  <button onclick="getWeather()" style="padding:8px 12px;margin-left:8px;">Get Weather</button>
</div>

<div id="result" style="text-align:center;margin-bottom:30px;"></div>

<!-- Weather fetch script -->
<script>
async function getWeather(){
  const city = document.getElementById("city").value.trim();
  const resultDiv = document.getElementById("result");

  if (!city) {
    resultDiv.innerHTML = "Please enter a city name.";
    return;
  }

  const apiKey = "<?= htmlspecialchars($openweather_api_key) ?>"; // configured in config.php
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;

  resultDiv.innerHTML = "Loading... ⛅";

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.cod === 200) {
      resultDiv.innerHTML = `
        <div class="card" style="margin:auto;max-width:350px;">
          <h3>${data.name}, ${data.sys.country}</h3>
          <p>🌤 ${data.weather[0].description}</p>
          <p>🌡 Temperature: ${data.main.temp}°C</p>
          <p>💨 Wind Speed: ${data.wind.speed} m/s</p>
          <p>💧 Humidity: ${data.main.humidity}%</p>
        </div>
      `;
    } else {
      resultDiv.innerHTML = "⚠️ City not found. Try another name.";
    }

  } catch (error) {
    resultDiv.innerHTML = "❌ Error fetching data. Please check your connection.";
    console.error(error);
  }
}
</script>

<?php include 'includes/footer.php'; ?>
