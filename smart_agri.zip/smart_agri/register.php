<?php
include('config.php');
include('includes/header.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($username && $email && $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>";
        } else {
            echo "<p style='color:red;'>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
    } else {
        echo "<p style='color:red;'>Please fill all fields!</p>";
    }
}
?>

<h2 style="text-align:center;">Register</h2>
<form method="POST" style="max-width:400px;margin:auto;">
    <input type="text" name="username" placeholder="Username" required style="width:100%;margin-bottom:10px;padding:8px;"><br>
    <input type="email" name="email" placeholder="Email" required style="width:100%;margin-bottom:10px;padding:8px;"><br>
    <input type="password" name="password" placeholder="Password" required style="width:100%;margin-bottom:10px;padding:8px;"><br>
    <button type="submit" style="padding:8px 15px;">Register</button>
</form>

<?php include('includes/footer.php'); ?>
