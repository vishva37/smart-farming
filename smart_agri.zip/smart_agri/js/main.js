document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("menuBtn");
  const nav = document.getElementById("navbar");
  btn.addEventListener("click", () => nav.classList.toggle("show"));
});
