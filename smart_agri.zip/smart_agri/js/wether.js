async function getWeather() {
    const city = document.getElementById("city").value.trim();
    const result = document.getElementById("result");
    if (!city) { result.textContent = "Please enter a city name."; return; }
    try {
        const res = await fetch(`https://wttr.in/${city}?format=3`);
        const text = await res.text();
        result.textContent = text.includes("Unknown") ? "City not found" : text;
    } catch (e) { result.textContent = "Error fetching weather data."; }
}