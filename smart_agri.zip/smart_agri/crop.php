<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<?php include('config.php'); include('includes/header.php'); ?>
<h2 style="text-align:center;">Crop Information</h2>
<div style="text-align:center;margin-bottom:20px;">
  <input type="text" id="searchCrop" placeholder="Search crop..." onkeyup="filterCrop()" style="padding:8px;width:60%;border-radius:8px;">
</div>
<table>
  <thead><tr><th>Crop</th><th>Season</th><th>Soil Type</th><th>Description</th></tr></thead>
  <tbody id="cropTable">
  <?php
  $result = $conn->query("SELECT * FROM crops");
  while($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['name']}</td><td>{$row['season']}</td><td>{$row['soil_type']}</td><td>{$row['description']}</td></tr>";
  }
  ?>
  </tbody>
</table>
<script>
function filterCrop(){
 const val=document.getElementById("searchCrop").value.toLowerCase();
 document.querySelectorAll("#cropTable tr").forEach(r=>{
   r.style.display=r.cells[0].textContent.toLowerCase().includes(val)?'':'none';
 });
}
</script>
<?php include('includes/footer.php'); ?>
